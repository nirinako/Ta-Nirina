
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

const searchInput = document.getElementById('searchInput');
const projects = document.querySelectorAll('.project-card');

searchInput.addEventListener('input', e => {
  const query = e.target.value.toLowerCase();
  projects.forEach(project => {
    const title = project.querySelector('h3').textContent.toLowerCase();
    const desc = project.querySelector('p')?.textContent.toLowerCase() || '';
    if (title.includes(query) || desc.includes(query)) {
      project.style.display = 'block';
    } else {
      project.style.display = 'none';
    }
  });
});

const darkModeToggle = document.getElementById('darkModeToggle');
darkModeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  if (document.body.classList.contains('dark')) {
    darkModeToggle.textContent = '☀️';
    localStorage.setItem('theme', 'dark');
  } else {
    darkModeToggle.textContent = '🌙';
    localStorage.setItem('theme', 'light');
  }
});

window.addEventListener('load', () => {
  const theme = localStorage.getItem('theme');
  if (theme === 'dark') {
    document.body.classList.add('dark');
    darkModeToggle.textContent = '☀️';
  }
});
